// filepath: src/providers/ArgusSessionProvider.tsx

'use client'

import { createContext, useContext, useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { useArgusStream }         from '@/hooks/useArgusStream'
import { useOpportunityHistory }  from '@/hooks/useOpportunityHistory'
import { useOpportunityDetect }   from '@/hooks/useOpportunityDetect'
import { usePipelineProgress }    from '@/hooks/usePipelineProgress'
import { calculateTokenBudget }   from '@/utils/tokenEstimator'
import type {
  RemoteData, StreamSessionState, PipelineProgress, PipelineStageId,
  OpportunityHistoryPage, Opportunity, OpportunityRecord,
  TokenBudget, SessionMeta,
} from '@/types'
import type { ExtractionFailure }          from '@/utils/opportunityExtractor'
import type { UseOpportunityHistoryReturn } from '@/hooks/useOpportunityHistory'

const MAX_HISTORY_TURNS = 6

interface ConversationTurn { readonly role: 'user' | 'assistant'; readonly content: string }

export interface ArgusSessionContextValue {
  sessionState:         RemoteData<StreamSessionState>
  isAtClearanceGate:    boolean
  sessionMeta:          SessionMeta | null
  progress:             PipelineProgress
  activeStageId:        PipelineStageId | null
  liveOpportunities:    readonly Opportunity[]
  extractionFailures:   readonly ExtractionFailure[]
  detectedCount:        number
  historyState:         RemoteData<OpportunityHistoryPage>
  writeError:           string | null
  deleteRecord:         UseOpportunityHistoryReturn['deleteRecord']
  clearAll:             UseOpportunityHistoryReturn['clearAll']
  loadMore:             UseOpportunityHistoryReturn['loadMore']
  refreshHistory:       UseOpportunityHistoryReturn['refresh']
  tokenBudget:          TokenBudget | null
  submitMessage:        (message: string) => Promise<void>
  abort:                () => void
  clearSession:         () => void
}

const ArgusSessionContext = createContext<ArgusSessionContextValue | null>(null)

export function ArgusSessionProvider({ children }: { children: ReactNode }) {
  const stream  = useArgusStream()
  const history = useOpportunityHistory(20)

  const tier = stream.sessionState.status === 'success'
    ? stream.sessionState.data.session.tier
    : null

  const { progress, activeStageId } = usePipelineProgress(
    stream.detectedStageIds as PipelineStageId[],
    stream.isAtClearanceGate,
    tier
  )

  const detect = useOpportunityDetect(
    stream.rawOpportunityBlocks,
    stream.sessionMeta,
    history.appendRecord
  )

  const conversationHistoryRef = useRef<ConversationTurn[]>([])
  const [, forceRender]        = useState(0)
  const bufferRef              = useRef('')
  const [tokenBudget, setTokenBudget] = useState<TokenBudget | null>(null)

  useEffect(() => { bufferRef.current = stream.buffer }, [stream.buffer])

  useEffect(() => {
    if (!stream.buffer) { setTokenBudget(null); return }
    const historyText = conversationHistoryRef.current.map((t) => `${t.role}: ${t.content}`).join('\n')
    setTokenBudget(calculateTokenBudget(stream.buffer, historyText))
  }, [stream.buffer])

  const submitMessage = useCallback(async (message: string): Promise<void> => {
    const currentBuffer  = bufferRef.current
    const updatedHistory: ConversationTurn[] = [
      ...conversationHistoryRef.current,
      ...(currentBuffer ? [{ role: 'assistant' as const, content: currentBuffer }] : []),
      { role: 'user' as const, content: message },
    ]
    const capped = updatedHistory.slice(-MAX_HISTORY_TURNS)
    conversationHistoryRef.current = capped
    forceRender((n) => n + 1)
    detect.resetSession()
    await stream.startStream(message, JSON.stringify(capped))
  }, [detect, stream])

  const clearSession = useCallback(() => {
    stream.clearSession()
    detect.resetSession()
    conversationHistoryRef.current = []
    forceRender((n) => n + 1)
    setTokenBudget(null)
  }, [stream, detect])

  const value: ArgusSessionContextValue = {
    sessionState: stream.sessionState, isAtClearanceGate: stream.isAtClearanceGate,
    sessionMeta: stream.sessionMeta, progress, activeStageId,
    liveOpportunities: detect.liveOpportunities, extractionFailures: detect.extractionFailures,
    detectedCount: detect.detectedCount,
    historyState: history.historyState, writeError: history.writeError,
    deleteRecord: history.deleteRecord, clearAll: history.clearAll,
    loadMore: history.loadMore, refreshHistory: history.refresh,
    tokenBudget, submitMessage, abort: stream.abort, clearSession,
  }

  return <ArgusSessionContext.Provider value={value}>{children}</ArgusSessionContext.Provider>
}

export function useArgusSession(): ArgusSessionContextValue {
  const ctx = useContext(ArgusSessionContext)
  if (!ctx) throw new Error('[ARGUS] useArgusSession must be called within <ArgusSessionProvider>')
  return ctx
}
