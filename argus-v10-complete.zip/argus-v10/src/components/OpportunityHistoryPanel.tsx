// filepath: src/components/OpportunityHistoryPanel.tsx

'use client'

import { useState, useId, useCallback, useMemo, type ChangeEvent } from 'react'
import { useArgusSession }  from '@/providers/ArgusSessionProvider'
import type { OpportunityRecord, OpportunityEffort, OpportunityConfidence } from '@/types'

const EFFORT_STYLE: Record<OpportunityEffort, string> = {
  low: 'text-green-400 border-green-900', medium: 'text-amber-400 border-amber-900', high: 'text-red-400 border-red-900',
}
const CONFIDENCE_STYLE: Record<OpportunityConfidence, string> = {
  speculative: 'text-zinc-500 border-zinc-800', likely: 'text-blue-400 border-blue-900', strong: 'text-cyan-400 border-cyan-900',
}

function HistoryRecordCard({ record, onDelete }: { record: OpportunityRecord; onDelete: (id: string) => void }) {
  const [expanded, setExpanded] = useState(false)
  const detectedDate = useMemo(() => new Date(record.detectedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }), [record.detectedAt])

  return (
    <li role="listitem" className="flex flex-col gap-2 p-3 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors duration-150">
      <div className="flex items-start justify-between gap-2">
        <button type="button" onClick={() => setExpanded((e) => !e)} aria-expanded={expanded} aria-label={`${expanded ? 'Collapse' : 'Expand'}: ${record.title}`}
          className="flex-1 text-left text-cyan-400 text-xs font-mono font-semibold leading-snug hover:text-cyan-300 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:rounded focus-visible:outline-offset-1 focus-visible:outline-cyan-500">
          {record.title}<span aria-hidden="true" className="ml-1.5 text-zinc-600">{expanded ? '▴' : '▾'}</span>
        </button>
        <button type="button" onClick={() => onDelete(record.id)} aria-label={`Delete: ${record.title}`}
          className="flex-shrink-0 px-1.5 py-0.5 rounded text-zinc-700 hover:text-red-400 text-xs font-mono border border-transparent hover:border-red-900 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-red-500">
          ✕
        </button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        <span aria-label={`Effort: ${record.effort}`} className={`px-1.5 py-0.5 rounded text-xs font-mono border bg-transparent ${EFFORT_STYLE[record.effort]}`}>{record.effort}</span>
        <span aria-label={`Confidence: ${record.confidence}`} className={`px-1.5 py-0.5 rounded text-xs font-mono border bg-transparent ${CONFIDENCE_STYLE[record.confidence]}`}>{record.confidence}</span>
        <span className="px-1.5 py-0.5 rounded text-xs font-mono text-zinc-600 border border-zinc-800">P{record.detected_at_process}</span>
      </div>
      {expanded && (
        <div className="flex flex-col gap-2 pt-1 border-t border-zinc-800">
          <div><p className="text-zinc-600 text-xs font-mono mb-0.5">Domain</p><p className="text-zinc-300 text-xs font-mono">{record.domain}</p></div>
          <div><p className="text-zinc-600 text-xs font-mono mb-0.5">Revenue Model</p><p className="text-zinc-300 text-xs font-mono leading-relaxed">{record.revenue_model}</p></div>
          <div><p className="text-zinc-600 text-xs font-mono mb-0.5">Description</p><p className="text-zinc-400 text-xs font-mono leading-relaxed">{record.description}</p></div>
          <div className="flex flex-col gap-0.5 pt-1 border-t border-zinc-900">
            <p className="text-zinc-700 text-xs font-mono truncate">Session: {record.sessionTitle}</p>
            <p className="text-zinc-700 text-xs font-mono">Detected: {detectedDate}</p>
          </div>
        </div>
      )}
    </li>
  )
}

export function OpportunityHistoryPanel() {
  const { historyState, writeError, deleteRecord, clearAll, loadMore, refreshHistory } = useArgusSession()
  const [searchQuery, setSearchQuery]   = useState('')
  const [confirmClear, setConfirmClear] = useState(false)
  const searchInputId                    = useId()

  const handleClearAll = useCallback(() => {
    if (!confirmClear) { setConfirmClear(true); return }
    clearAll(); setConfirmClear(false)
  }, [confirmClear, clearAll])

  const filteredRecords = useMemo(() => {
    if (historyState.status !== 'success') return []
    const q = searchQuery.toLowerCase().trim()
    if (!q) return historyState.data.records
    return historyState.data.records.filter((r) =>
      r.title.toLowerCase().includes(q) || r.domain.toLowerCase().includes(q) ||
      r.description.toLowerCase().includes(q) || r.sessionTitle.toLowerCase().includes(q)
    )
  }, [historyState, searchQuery])

  const totalCount = historyState.status === 'success' ? historyState.data.totalCount : 0
  const hasMore    = historyState.status === 'success' ? historyState.data.hasMore : false

  return (
    <section aria-label={`Opportunity History — ${totalCount} total`} className="flex flex-col h-full bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
      <header className="flex flex-col gap-2 px-3 py-2 border-b border-zinc-800 bg-zinc-900/50 flex-shrink-0">
        <div className="flex items-center justify-between">
          <h2 className="text-zinc-300 text-xs font-mono font-semibold tracking-widest uppercase">Opportunity History</h2>
          <div className="flex items-center gap-1.5">
            <button type="button" onClick={refreshHistory} aria-label="Refresh history"
              className="px-2 py-0.5 rounded text-zinc-500 hover:text-zinc-300 text-xs font-mono border border-transparent hover:border-zinc-700 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-zinc-400">↻</button>
            {totalCount > 0 && (
              <button type="button" onClick={handleClearAll} onBlur={() => setConfirmClear(false)}
                aria-label={confirmClear ? 'Confirm clear all' : 'Clear all history'}
                className={`px-2 py-0.5 rounded text-xs font-mono border transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 ${confirmClear ? 'text-red-400 border-red-900 bg-red-950 focus-visible:outline-red-500' : 'text-zinc-600 border-zinc-800 hover:text-red-400 hover:border-red-900 focus-visible:outline-zinc-400'}`}>
                {confirmClear ? 'Confirm Clear' : 'Clear All'}
              </button>
            )}
          </div>
        </div>
        <div>
          <label htmlFor={searchInputId} className="sr-only">Search opportunity history</label>
          <input id={searchInputId} type="search" value={searchQuery} onChange={(e: ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
            placeholder="Search by title, domain, or session…"
            className="w-full px-3 py-1.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs font-mono placeholder:text-zinc-600 focus:outline-none focus:border-zinc-600 focus:ring-1 focus:ring-zinc-700" />
        </div>
      </header>

      {writeError && (
        <div role="alert" aria-live="assertive" className="flex-shrink-0 px-3 py-2 bg-red-950/50 border-b border-red-900/40">
          <p className="text-red-400 text-xs font-mono">{writeError}</p>
        </div>
      )}

      <div className="flex-1 overflow-y-auto overscroll-contain p-3">
        {historyState.status === 'loading' && (
          <div role="status" aria-live="polite" aria-label="Loading history" className="flex flex-col gap-2 animate-pulse">
            {[...Array(3)].map((_, i) => <div key={i} className="h-16 bg-zinc-900 rounded-lg border border-zinc-800" />)}
          </div>
        )}
        {historyState.status === 'error' && <div role="alert" aria-live="assertive"><p className="text-red-400 text-xs font-mono">{historyState.message}</p></div>}
        {historyState.status === 'success' && filteredRecords.length === 0 && (
          <p className="text-zinc-700 text-xs font-mono text-center py-8 leading-relaxed">
            {searchQuery ? `No results for "${searchQuery}"` : 'No opportunities saved yet.'}
          </p>
        )}
        {filteredRecords.length > 0 && (
          <ul role="list" aria-label={`${filteredRecords.length} opportunity records`} className="flex flex-col gap-2">
            {filteredRecords.map((record) => <HistoryRecordCard key={record.id} record={record} onDelete={deleteRecord} />)}
          </ul>
        )}
        {hasMore && !searchQuery && (
          <button type="button" onClick={loadMore} aria-label="Load more records"
            className="w-full mt-3 px-3 py-2 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-400 text-xs font-mono border border-zinc-800 hover:border-zinc-600 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400">
            Load More
          </button>
        )}
      </div>
    </section>
  )
}
