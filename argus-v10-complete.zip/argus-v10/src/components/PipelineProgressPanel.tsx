// filepath: src/components/PipelineProgressPanel.tsx

'use client'

import { memo, useMemo } from 'react'
import { useArgusSession }        from '@/providers/ArgusSessionProvider'
import { ProcessStageIndicator, type StageStatus } from './ProcessStageIndicator'
import { PIPELINE_STAGES, STAGES_FOR_TIER, type PipelineStageDefinition } from '@/types/pipeline'
import type { PipelineStageId, PipelineTier } from '@/types'

function resolveStageStatus(stage: PipelineStageDefinition, tier: PipelineTier | null, currentStage: PipelineStageId | null, completedStages: readonly PipelineStageId[]): StageStatus {
  if (tier !== null && !stage.tiers.includes(tier)) return 'skipped'
  if (completedStages.includes(stage.id as PipelineStageId)) return 'complete'
  if (currentStage === stage.id) return 'active'
  return 'idle'
}

const TIER_LABELS: Record<PipelineTier, string> = { 1: 'FULL', 2: 'STREAMLINED', 3: 'COMPONENT' }

export const PipelineProgressPanel = memo(function PipelineProgressPanel() {
  const { progress } = useArgusSession()
  const { tier, currentStage, completedStages } = progress
  const archStages = useMemo(() => PIPELINE_STAGES.filter((s) => s.phase === 'architecture'),   [])
  const implStages = useMemo(() => PIPELINE_STAGES.filter((s) => s.phase === 'implementation'), [])
  const completedCount = completedStages.length
  const totalActive    = tier ? STAGES_FOR_TIER(tier).length : PIPELINE_STAGES.length

  return (
    <section aria-label="ARGUS Pipeline Progress" className="flex flex-col h-full bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
      <header className="flex items-center justify-between px-3 py-2 border-b border-zinc-800 bg-zinc-900/50 flex-shrink-0">
        <h2 className="text-zinc-300 text-xs font-mono font-semibold tracking-widest uppercase">Pipeline</h2>
        <div className="flex items-center gap-2">
          {tier && <span aria-label={`Tier: ${TIER_LABELS[tier]}`} className="text-amber-500 text-xs font-mono">T{tier}</span>}
          <span aria-label={`${completedCount} of ${totalActive} stages complete`} className="text-zinc-500 text-xs font-mono">{completedCount}/{totalActive}</span>
        </div>
      </header>
      <div className="flex-1 overflow-y-auto overscroll-contain py-1" role="list" aria-label="Pipeline stages">
        <div role="group" aria-label="Phase 1 — Architecture" className="px-2 pt-1 pb-0.5">
          <p aria-hidden="true" className="text-zinc-700 text-xs font-mono uppercase tracking-widest px-2 pt-1 pb-0.5">Phase 1</p>
          {archStages.map((stage) => <ProcessStageIndicator key={stage.id} stage={stage} status={resolveStageStatus(stage, tier, currentStage, completedStages)} />)}
        </div>
        <hr aria-hidden="true" className="border-zinc-800 mx-4 my-1" />
        <div role="group" aria-label="Phase 2 — Implementation" className="px-2 py-1">
          <p aria-hidden="true" className="text-zinc-700 text-xs font-mono uppercase tracking-widest px-2 pt-1 pb-0.5">Phase 2</p>
          {implStages.map((stage) => <ProcessStageIndicator key={stage.id} stage={stage} status={resolveStageStatus(stage, tier, currentStage, completedStages)} />)}
        </div>
      </div>
      <div role="progressbar" aria-valuenow={completedCount} aria-valuemin={0} aria-valuemax={totalActive}
        aria-label={`Pipeline ${Math.round((completedCount / Math.max(totalActive, 1)) * 100)}% complete`} className="h-0.5 bg-zinc-900 flex-shrink-0">
        <div aria-hidden="true" className="h-full bg-amber-500 transition-all duration-500" style={{ width: `${(completedCount / Math.max(totalActive, 1)) * 100}%` }} />
      </div>
    </section>
  )
})
