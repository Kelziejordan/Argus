// filepath: src/components/boundaries/RootErrorBoundary.tsx

'use client'

import React, { Component, type ErrorInfo, type ReactNode } from 'react'
import { generateCorrelationId } from '@/utils/correlationId'
import type { ErrorMetadata } from '@/types'

function RootFallbackUI({ error, correlationId, onReload }: {
  error: Error | null; correlationId: string | null; onReload: () => void
}): ReactNode {
  return (
    <main role="alert" aria-live="assertive" aria-atomic="true"
      className="flex flex-col items-center justify-center min-h-screen w-full bg-zinc-950 p-8 gap-6">
      <div className="flex flex-col items-center gap-3 text-center max-w-lg">
        <div aria-hidden="true" className="flex items-center justify-center w-12 h-12 rounded-full bg-red-950 border border-red-800">
          <span className="text-red-400 text-xl font-bold">✕</span>
        </div>
        <h1 className="text-red-400 text-sm font-mono font-semibold tracking-widest uppercase">ARGUS — Critical Rendering Failure</h1>
        <p className="text-zinc-400 text-xs font-mono leading-relaxed">A fatal error bypassed all panel boundaries. Your session data is preserved in storage. Reload to resume.</p>
      </div>
      {error?.message && (
        <div className="w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-lg p-4">
          <p className="text-zinc-300 text-xs font-mono leading-relaxed break-words">{error.message}</p>
        </div>
      )}
      {correlationId && <p className="text-zinc-600 text-xs font-mono" aria-label={`Error ID: ${correlationId}`}>ID: {correlationId}</p>}
      <button type="button" onClick={onReload}
        className="px-6 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono font-semibold rounded border border-zinc-600 hover:border-zinc-400 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-300"
        aria-label="Reload the ARGUS application">
        ↺ Reload ARGUS
      </button>
    </main>
  )
}

interface RootErrorBoundaryState {
  readonly hasError: boolean; readonly error: Error | null; readonly correlationId: string | null
}

// ARGUS-EXCEPTION | Mandate: 5 | Same reason as PanelErrorBoundary
export class RootErrorBoundary extends Component<{ children: ReactNode }, RootErrorBoundaryState> {
  constructor(props: { children: ReactNode }) {
    super(props)
    this.state = { hasError: false, error: null, correlationId: null }
  }
  static getDerivedStateFromError(error: Error): RootErrorBoundaryState {
    return { hasError: true, error, correlationId: generateCorrelationId() }
  }
  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    const metadata: ErrorMetadata & { boundary: string; componentStack: string | null } = {
      action: 'root_error_boundary_catch', boundary: 'root',
      payload: { message: error.message },
      state: { correlationId: this.state.correlationId },
      timestamp: new Date().toISOString(),
      correlationId: this.state.correlationId ?? generateCorrelationId(),
      componentStack: errorInfo.componentStack ?? null,
    }
    console.error('[ARGUS] RootErrorBoundary — CRITICAL', { message: error.message, stack: error.stack?.slice(0, 1000), ...metadata })
  }
  handleReload = (): void => { if (typeof window !== 'undefined') window.location.reload() }
  render(): ReactNode {
    if (!this.state.hasError) return this.props.children
    return <RootFallbackUI error={this.state.error} correlationId={this.state.correlationId} onReload={this.handleReload} />
  }
}
