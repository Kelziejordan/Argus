// filepath: src/components/boundaries/PanelErrorBoundary.tsx

'use client'

import React, { Component, type ErrorInfo, type ReactNode } from 'react'
import { generateCorrelationId } from '@/utils/correlationId'
import type { ErrorMetadata } from '@/types'

interface PanelFallbackUIProps {
  readonly panelName:     string
  readonly error:         Error | null
  readonly correlationId: string | null
  readonly onReset:       () => void
}

function PanelFallbackUI({ panelName, error, correlationId, onReset }: PanelFallbackUIProps): ReactNode {
  return (
    <div role="alert" aria-live="assertive" aria-atomic="true"
      className="flex flex-col h-full w-full p-4 gap-3 bg-zinc-950 border border-red-900/40 rounded-lg overflow-hidden">
      <div className="flex items-center gap-2 flex-shrink-0">
        <span aria-hidden="true" className="flex items-center justify-center w-5 h-5 rounded-full bg-red-950 border border-red-800 text-red-400 text-xs font-bold select-none">✕</span>
        <span className="text-red-400 text-xs font-mono font-semibold tracking-widest uppercase truncate">{panelName} — Panel Failure</span>
      </div>
      <p className="text-zinc-400 text-xs font-mono leading-relaxed line-clamp-3 flex-shrink-0">
        {error?.message ?? 'An unexpected rendering error occurred in this panel.'}
      </p>
      {correlationId && (
        <p className="text-zinc-600 text-xs font-mono truncate flex-shrink-0" aria-label={`Error correlation ID: ${correlationId}`}>
          ID: {correlationId}
        </p>
      )}
      <button type="button" onClick={onReset}
        className="mt-auto px-3 py-1.5 flex-shrink-0 self-start bg-zinc-900 hover:bg-zinc-800 active:bg-zinc-700 text-zinc-300 text-xs font-mono rounded border border-zinc-700 hover:border-zinc-500 transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400"
        aria-label={`Retry the ${panelName} panel`}>
        ↺ Retry Panel
      </button>
    </div>
  )
}

interface PanelErrorBoundaryProps {
  readonly children:  ReactNode
  readonly panelName: string
  readonly fallback?: ReactNode
}

interface PanelErrorBoundaryState {
  readonly hasError:      boolean
  readonly error:         Error | null
  readonly correlationId: string | null
}

// ARGUS-EXCEPTION | Mandate: 5
// Reason: React requires class components for Error Boundaries.
//         No hooks equivalent exists for componentDidCatch in React 18.
// Scope: This file only. All other components are functional.
// Revisit: When React introduces a stable hooks-based Error Boundary API.
export class PanelErrorBoundary extends Component<PanelErrorBoundaryProps, PanelErrorBoundaryState> {
  constructor(props: PanelErrorBoundaryProps) {
    super(props)
    this.state = { hasError: false, error: null, correlationId: null }
  }

  static getDerivedStateFromError(error: Error): PanelErrorBoundaryState {
    return { hasError: true, error, correlationId: generateCorrelationId() }
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    const metadata: ErrorMetadata & { panelName: string; componentStack: string | null } = {
      action:         'panel_error_boundary_catch',
      panelName:      this.props.panelName,
      payload:        { message: error.message },
      state:          { correlationId: this.state.correlationId },
      timestamp:      new Date().toISOString(),
      correlationId:  this.state.correlationId ?? generateCorrelationId(),
      componentStack: errorInfo.componentStack ?? null,
    }
    console.error(`[ARGUS] PanelErrorBoundary — "${this.props.panelName}"`, {
      message: error.message,
      stack:   error.stack?.slice(0, 500),
      ...metadata,
    })
  }

  handleReset = (): void => {
    this.setState({ hasError: false, error: null, correlationId: null })
  }

  render(): ReactNode {
    if (!this.state.hasError) return this.props.children
    if (this.props.fallback)  return this.props.fallback
    return (
      <PanelFallbackUI
        panelName={this.props.panelName}
        error={this.state.error}
        correlationId={this.state.correlationId}
        onReset={this.handleReset}
      />
    )
  }
}
