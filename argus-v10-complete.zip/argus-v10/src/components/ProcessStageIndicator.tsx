// filepath: src/components/ProcessStageIndicator.tsx

'use client'

import { memo } from 'react'
import type { PipelineStageDefinition } from '@/types/pipeline'

export type StageStatus = 'idle' | 'active' | 'complete' | 'skipped'

const STATUS_DOT: Record<StageStatus, string>    = { idle: 'bg-zinc-700', active: 'bg-amber-400 animate-pulse', complete: 'bg-green-500', skipped: 'bg-zinc-800' }
const STATUS_LABEL: Record<StageStatus, string>  = { idle: 'text-zinc-500', active: 'text-amber-400 font-semibold', complete: 'text-green-400', skipped: 'text-zinc-700 line-through' }
const STATUS_NUM: Record<StageStatus, string>    = { idle: 'text-zinc-600', active: 'text-amber-500', complete: 'text-green-500', skipped: 'text-zinc-800' }
const STATUS_ARIA: Record<StageStatus, string>   = { idle: 'pending', active: 'in progress', complete: 'complete', skipped: 'skipped for this tier' }

export const ProcessStageIndicator = memo(function ProcessStageIndicator({ stage, status }: { stage: PipelineStageDefinition; status: StageStatus }) {
  return (
    <div role="listitem" aria-label={`Process ${stage.processNumber}: ${stage.label} — ${STATUS_ARIA[status]}`} aria-busy={status === 'active'}
      className="flex items-center gap-2 py-1 px-2 rounded hover:bg-zinc-900/50 transition-colors">
      <span aria-hidden="true" className={`flex-shrink-0 w-1.5 h-1.5 rounded-full ${STATUS_DOT[status]}`}/>
      <span aria-hidden="true" className={`flex-shrink-0 font-mono text-xs w-5 text-right ${STATUS_NUM[status]}`}>{stage.processNumber}</span>
      <span aria-hidden="true" className={`font-mono text-xs truncate ${STATUS_LABEL[status]}`}>{stage.shortLabel}</span>
    </div>
  )
})
