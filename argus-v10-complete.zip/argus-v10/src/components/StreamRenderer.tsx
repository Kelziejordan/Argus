// filepath: src/components/StreamRenderer.tsx

'use client'

import { memo, useMemo } from 'react'

type TextSegment = { type: 'text'; content: string }
type CodeSegment = { type: 'code'; lang: string; content: string; partial: boolean }
type Segment = TextSegment | CodeSegment

function parseSegments(raw: string): Segment[] {
  const segments: Segment[] = []
  const completeBlock = /```(\w*)\n([\s\S]*?)```/g
  let lastIndex = 0; let match: RegExpExecArray | null
  while ((match = completeBlock.exec(raw)) !== null) {
    if (match.index > lastIndex) segments.push({ type: 'text', content: raw.slice(lastIndex, match.index) })
    segments.push({ type: 'code', lang: match[1] ?? '', content: match[2] ?? '', partial: false })
    lastIndex = match.index + match[0].length
  }
  const remaining = raw.slice(lastIndex)
  const openTagIdx = remaining.indexOf('```')
  if (openTagIdx !== -1) {
    const before = remaining.slice(0, openTagIdx)
    const afterTag = remaining.slice(openTagIdx + 3)
    const newlineIdx = afterTag.indexOf('\n')
    const lang = newlineIdx !== -1 ? afterTag.slice(0, newlineIdx) : ''
    const codeContent = newlineIdx !== -1 ? afterTag.slice(newlineIdx + 1) : afterTag
    if (before) segments.push({ type: 'text', content: before })
    segments.push({ type: 'code', lang, content: codeContent, partial: true })
  } else if (remaining) {
    segments.push({ type: 'text', content: remaining })
  }
  return segments
}

type LineStyle = 'separator' | 'process' | 'mandate' | 'warning' | 'label' | 'prose'
function classifyLine(line: string): LineStyle {
  if (/^[━─═]{4,}/.test(line))                        return 'separator'
  if (/^PROCESS\s+\d+\s*[—\-–]/i.test(line))         return 'process'
  if (/^[✓✗]\s+Mandate/i.test(line))                 return 'mandate'
  if (/^⚠️/.test(line))                               return 'warning'
  if (/^[A-Z][A-Z\s&\-–—/]{4,}:?\s*$/.test(line.trim())) return 'label'
  return 'prose'
}

function renderTextLine(line: string, idx: number): React.ReactNode {
  const style = classifyLine(line)
  const key = `line-${idx}`
  switch (style) {
    case 'separator': return <hr key={key} aria-hidden="true" className="border-0 border-t border-zinc-800 my-1" />
    case 'process':   return <p key={key} className="text-amber-400 font-mono font-semibold text-xs tracking-wide mt-3 mb-1">{line}</p>
    case 'mandate':   return <p key={key} className={`font-mono text-xs leading-relaxed ${line.startsWith('✓') ? 'text-green-400' : 'text-red-400'}`}>{line}</p>
    case 'warning':   return <p key={key} className="text-yellow-400 font-mono text-xs font-semibold mt-2 mb-1">{line}</p>
    case 'label':     return <p key={key} className="text-zinc-300 font-mono text-xs font-semibold tracking-widest uppercase mt-2">{line}</p>
    default:          return <p key={key} className="text-zinc-300 font-mono text-xs leading-relaxed">{line || '\u00A0'}</p>
  }
}

function CodeBlock({ lang, content, partial }: { lang: string; content: string; partial: boolean }) {
  const filepathMatch = content.match(/^\/\/\s*filepath:\s*(.+?)(?:\n|$)/m)
  const filepath = filepathMatch ? filepathMatch[1]?.trim() : null
  return (
    <div className="my-2 rounded-md overflow-hidden border border-zinc-800 bg-zinc-900">
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-zinc-800 bg-zinc-900/80">
        <span className="text-zinc-500 text-xs font-mono">{filepath ?? (lang || 'code')}</span>
        {partial && <span aria-label="Streaming" className="flex items-center gap-1 text-amber-500 text-xs font-mono"><span aria-hidden="true" className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"/>streaming</span>}
      </div>
      <pre className="overflow-x-auto p-4"><code className="text-zinc-200 text-xs font-mono leading-relaxed whitespace-pre">{content}</code></pre>
    </div>
  )
}

export const StreamRenderer = memo(function StreamRenderer({ content, className = '' }: { content: string; className?: string }) {
  const segments = useMemo(() => parseSegments(content), [content])
  return (
    <div className={`flex flex-col gap-0.5 ${className}`} aria-live="polite" aria-atomic="false" aria-relevant="additions">
      {segments.map((segment, segIdx) => {
        if (segment.type === 'code') return <CodeBlock key={`seg-${segIdx}`} lang={segment.lang} content={segment.content} partial={segment.partial} />
        return segment.content.split('\n').map((line, lineIdx) => renderTextLine(line, segIdx * 10_000 + lineIdx))
      })}
    </div>
  )
})
