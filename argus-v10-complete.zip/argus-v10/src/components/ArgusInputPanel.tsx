// filepath: src/components/ArgusInputPanel.tsx

'use client'

import { useState, useCallback, useRef, useEffect, type KeyboardEvent, type ChangeEvent } from 'react'
import { useArgusSession }          from '@/providers/ArgusSessionProvider'
import { formatTokenBudgetSummary, getTierBlockedReason } from '@/utils/tokenEstimator'
import type { PipelineTier } from '@/types'

export function ArgusInputPanel() {
  const { sessionState, tokenBudget, submitMessage, abort, clearSession } = useArgusSession()
  const [value, setValue] = useState('')
  const textareaRef       = useRef<HTMLTextAreaElement>(null)
  const isLoading         = sessionState.status === 'loading'
  const isStreaming       = sessionState.status === 'loading' || sessionState.status === 'success'
  const isIdle            = sessionState.status === 'idle'
  const isError           = sessionState.status === 'error'
  const tier1Blocked      = tokenBudget ? !tokenBudget.canSubmitTier[1] : false
  const tier1Reason       = tokenBudget ? getTierBlockedReason(tokenBudget, 1) : null
  const canSubmit         = value.trim().length > 0 && !isLoading && !tier1Blocked

  useEffect(() => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, 240)}px`
  }, [value])

  const handleSubmit = useCallback(async () => {
    const trimmed = value.trim()
    if (!trimmed || !canSubmit) return
    setValue('')
    await submitMessage(trimmed)
  }, [value, canSubmit, submitMessage])

  const handleKeyDown = useCallback((e: KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); handleSubmit() }
  }, [handleSubmit])

  return (
    <section aria-label="ARGUS Input" className="flex flex-col bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
      {tokenBudget && (
        <div role="status" aria-live="polite" aria-label={formatTokenBudgetSummary(tokenBudget)} className="flex-shrink-0">
          <div aria-hidden="true" className="h-0.5 bg-zinc-900 w-full">
            <div className={`h-full transition-all duration-300 ${tokenBudget.isCritical ? 'bg-red-500' : tokenBudget.isNearLimit ? 'bg-yellow-500' : 'bg-green-600'}`}
              style={{ width: `${Math.min((tokenBudget.estimated / tokenBudget.limit) * 100, 100)}%` }} />
          </div>
        </div>
      )}
      <div className="flex gap-2 p-3">
        <div className="flex-1 flex flex-col gap-1">
          <textarea ref={textareaRef} value={value} onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setValue(e.target.value)}
            onKeyDown={handleKeyDown} rows={3} disabled={isLoading}
            aria-label="ARGUS prompt input. Press Command Enter to submit."
            placeholder={isLoading ? 'ARGUS is processing…' : 'Describe what you want to build. ARGUS will architect it.'}
            className="w-full resize-none bg-zinc-900 rounded-md text-zinc-100 text-xs font-mono leading-relaxed placeholder:text-zinc-600 border border-zinc-800 focus:border-zinc-600 focus:outline-none focus:ring-1 focus:ring-zinc-600 px-3 py-2.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed min-h-[72px] max-h-[240px]" />
          <div className="flex items-center justify-between gap-2">
            <span aria-hidden="true" className="text-zinc-700 text-xs font-mono">⌘↵ submit</span>
            {tokenBudget && (
              <span aria-live="polite" className={`text-xs font-mono ${tokenBudget.isCritical ? 'text-red-400' : tokenBudget.isNearLimit ? 'text-yellow-500' : 'text-zinc-600'}`}>
                {formatTokenBudgetSummary(tokenBudget)}
              </span>
            )}
            {tokenBudget && (
              <div aria-label="Tier availability" className="flex items-center gap-1">
                {([1, 2, 3] as PipelineTier[]).map((t) => (
                  <span key={t} aria-label={`Tier ${t} ${tokenBudget.canSubmitTier[t] ? 'available' : 'unavailable'}`}
                    className={`px-2 py-0.5 rounded text-xs font-mono border ${tokenBudget.canSubmitTier[t] ? 'text-amber-400 border-amber-800/40 bg-amber-950/30' : 'text-zinc-700 border-zinc-800'}`}>
                    T{t}
                  </span>
                ))}
              </div>
            )}
          </div>
          {tier1Blocked && tier1Reason && <p role="alert" className="text-red-400 text-xs font-mono leading-relaxed">{tier1Reason}</p>}
          {isError && sessionState.status === 'error' && <p role="alert" className="text-red-400 text-xs font-mono">{sessionState.message}</p>}
        </div>
        <div className="flex flex-col gap-2 flex-shrink-0">
          {(!isStreaming || isIdle || isError) ? (
            <button type="button" onClick={handleSubmit} disabled={!canSubmit} aria-label="Submit prompt to ARGUS"
              className={`px-4 py-2 rounded font-mono text-xs font-semibold border transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400 ${canSubmit ? 'bg-amber-500 hover:bg-amber-400 text-zinc-950 border-amber-400' : 'bg-zinc-900 text-zinc-600 border-zinc-800 cursor-not-allowed'}`}>
              Run
            </button>
          ) : (
            <button type="button" onClick={abort} aria-label="Abort current ARGUS stream"
              className="px-4 py-2 rounded font-mono text-xs font-semibold bg-red-950 hover:bg-red-900 text-red-400 border border-red-900 hover:border-red-700 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-400">
              Abort
            </button>
          )}
          <button type="button" onClick={clearSession} aria-label="Clear current session"
            className="px-4 py-2 rounded font-mono text-xs bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border border-zinc-800 hover:border-zinc-600 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400">
            New
          </button>
        </div>
      </div>
    </section>
  )
}
