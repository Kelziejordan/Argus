// filepath: src/components/NextMovePanel.tsx

'use client'

import { useState, useCallback, useId } from 'react'
import { useArgusSession }              from '@/providers/ArgusSessionProvider'
import type { ClearanceOptionType }     from '@/types'

const BUTTON_STYLE: Record<ClearanceOptionType, string> = {
  APPROVE:   'bg-green-950 hover:bg-green-900 text-green-400 border-green-900 hover:border-green-700',
  AMEND:     'bg-amber-950 hover:bg-amber-900 text-amber-400 border-amber-900 hover:border-amber-700',
  CHALLENGE: 'bg-zinc-900  hover:bg-zinc-800  text-zinc-300  border-zinc-800  hover:border-zinc-600',
  SIMPLIFY:  'bg-zinc-900  hover:bg-zinc-800  text-zinc-300  border-zinc-800  hover:border-zinc-600',
}

export function NextMovePanel() {
  const { progress, sessionState, submitMessage } = useArgusSession()
  const [amendProcess, setAmendProcess] = useState('')
  const [showAmend, setShowAmend]       = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const amendInputId                    = useId()

  const isAtGate   = progress.isAtClearanceGate
  const isStreaming = sessionState.status === 'loading' || sessionState.status === 'success'
  const isIdle     = sessionState.status === 'idle'

  const handleClearance = useCallback(async (type: ClearanceOptionType) => {
    if (type === 'AMEND') { setShowAmend(true); return }
    setIsSubmitting(true)
    await submitMessage(type)
    setIsSubmitting(false)
  }, [submitMessage])

  const handleAmendSubmit = useCallback(async () => {
    const processName = amendProcess.trim()
    if (!processName) return
    setIsSubmitting(true)
    setShowAmend(false)
    setAmendProcess('')
    await submitMessage(`AMEND [${processName}]`)
    setIsSubmitting(false)
  }, [amendProcess, submitMessage])

  return (
    <section aria-label="Next Move — ARGUS Clearance Gate" className="flex flex-col h-full bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
      <header className="px-3 py-2 border-b border-zinc-800 bg-zinc-900/50 flex-shrink-0">
        <h2 className="text-zinc-300 text-xs font-mono font-semibold tracking-widest uppercase">Next Move</h2>
      </header>

      <div className="flex-1 flex flex-col justify-center p-3 gap-2 overflow-y-auto" aria-live="polite" aria-atomic="false">
        {isIdle && <p className="text-zinc-600 text-xs font-mono text-center leading-relaxed">Submit a prompt to begin the ARGUS pipeline.</p>}

        {isStreaming && !isAtGate && (
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <span aria-hidden="true" className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse flex-shrink-0" />
              <span className="text-amber-400 text-xs font-mono">Pipeline executing…</span>
            </div>
            <p className="text-zinc-600 text-xs font-mono leading-relaxed">Clearance options will appear when the pipeline pauses for architect decision.</p>
          </div>
        )}

        {isAtGate && !showAmend && (
          <div className="flex flex-col gap-2">
            <p className="text-yellow-400 text-xs font-mono font-semibold mb-1" aria-label="Architecture complete. Select a clearance action.">⚠️ Clearance Required</p>
            {progress.activeClearanceOptions.map((option) => (
              <button key={option.type} type="button" onClick={() => handleClearance(option.type)} disabled={isSubmitting}
                aria-label={`${option.label}: ${option.description}`}
                className={`w-full px-3 py-2 rounded text-left text-xs font-mono border transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400 ${BUTTON_STYLE[option.type]}`}>
                <span className="font-semibold block">{option.label}</span>
                <span className="text-xs opacity-70 leading-relaxed block mt-0.5">{option.description}</span>
              </button>
            ))}
          </div>
        )}

        {showAmend && (
          <div className="flex flex-col gap-2">
            <label htmlFor={amendInputId} className="text-amber-400 text-xs font-mono font-semibold">AMEND — Process Name</label>
            <input id={amendInputId} type="text" value={amendProcess} onChange={(e) => setAmendProcess(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleAmendSubmit(); if (e.key === 'Escape') { setShowAmend(false); setAmendProcess('') } }}
              placeholder="e.g. VERIFIER, CHAOS ENGINEER" aria-describedby={`${amendInputId}-hint`} autoFocus
              className="w-full px-3 py-2 rounded bg-zinc-900 border border-zinc-700 text-zinc-200 text-xs font-mono placeholder:text-zinc-600 focus:outline-none focus:border-amber-600 focus:ring-1 focus:ring-amber-700" />
            <p id={`${amendInputId}-hint`} className="text-zinc-600 text-xs font-mono">Enter ↵ to submit · Esc to cancel</p>
            <div className="flex gap-2">
              <button type="button" onClick={handleAmendSubmit} disabled={!amendProcess.trim() || isSubmitting} aria-label="Submit AMEND request"
                className="flex-1 px-3 py-1.5 rounded font-mono text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-zinc-950 border border-amber-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400">
                Submit AMEND
              </button>
              <button type="button" onClick={() => { setShowAmend(false); setAmendProcess('') }} aria-label="Cancel AMEND"
                className="px-3 py-1.5 rounded font-mono text-xs bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border border-zinc-800 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400">
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
