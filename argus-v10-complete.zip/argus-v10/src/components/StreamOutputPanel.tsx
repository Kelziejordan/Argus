// filepath: src/components/StreamOutputPanel.tsx

'use client'

import { useRef, useEffect, useState, useCallback } from 'react'
import { useArgusSession }  from '@/providers/ArgusSessionProvider'
import { StreamRenderer }   from './StreamRenderer'
import { STAGE_BY_ID }      from '@/types/pipeline'

function StreamingCursor() {
  return <span aria-hidden="true" className="inline-block w-1.5 h-3.5 bg-amber-400 animate-pulse ml-0.5 align-text-bottom" />
}

function IdleState() {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-4 py-16">
      <div aria-hidden="true" className="text-zinc-800 font-mono text-xs tracking-widest uppercase select-none">━━━━━━━━━━━━━━━━━━━━━━━━━━━━</div>
      <p className="text-zinc-600 text-xs font-mono text-center leading-relaxed max-w-xs">ARGUS V10 standing by.{'\n'}Describe a build to begin the pipeline.</p>
      <div aria-hidden="true" className="text-zinc-800 font-mono text-xs tracking-widest uppercase select-none">━━━━━━━━━━━━━━━━━━━━━━━━━━━━</div>
    </div>
  )
}

export function StreamOutputPanel() {
  const { sessionState, activeStageId } = useArgusSession()
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const bottomRef          = useRef<HTMLDivElement>(null)
  const isUserScrollingRef = useRef(false)
  const [showScrollBtn, setShowScrollBtn] = useState(false)

  const isLoading   = sessionState.status === 'loading'
  const isSuccess   = sessionState.status === 'success'
  const content     = isSuccess ? sessionState.data.panelContent.main : ''
  const activeStage = activeStageId !== null ? STAGE_BY_ID[activeStageId] : null

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
    setShowScrollBtn(false)
    isUserScrollingRef.current = false
  }, [])

  useEffect(() => {
    const container = scrollContainerRef.current
    if (!container) return
    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container
      const isScrolledUp = scrollHeight - scrollTop - clientHeight > 100
      isUserScrollingRef.current = isScrolledUp
      setShowScrollBtn(isScrolledUp)
    }
    container.addEventListener('scroll', handleScroll, { passive: true })
    return () => container.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    if (!isUserScrollingRef.current) {
      bottomRef.current?.scrollIntoView({ behavior: 'instant' })
    }
  }, [content])

  return (
    <section aria-label="ARGUS Stream Output" className="relative flex flex-col h-full bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
      <header className="flex items-center justify-between px-3 py-2 border-b border-zinc-800 bg-zinc-900/50 flex-shrink-0">
        <h2 className="text-zinc-300 text-xs font-mono font-semibold tracking-widest uppercase">Stream Output</h2>
        {activeStage && (
          <span aria-live="polite" aria-label={`Active: ${activeStage.label}`} className="flex items-center gap-1.5 text-amber-400 text-xs font-mono">
            <span aria-hidden="true" className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="truncate max-w-[160px]">{activeStage.label}</span>
          </span>
        )}
        {isLoading && !activeStage && (
          <span aria-live="polite" aria-label="Initialising pipeline" className="flex items-center gap-1.5 text-zinc-500 text-xs font-mono">
            <span aria-hidden="true" className="w-1.5 h-1.5 rounded-full bg-zinc-500 animate-pulse" />
            Initialising…
          </span>
        )}
      </header>

      <div ref={scrollContainerRef} className="flex-1 overflow-y-auto overscroll-contain p-4" tabIndex={0} aria-label="Stream output content — scrollable">
        {sessionState.status === 'idle' && <IdleState />}
        {isLoading && !content && (
          <div role="status" aria-live="polite" aria-label="ARGUS pipeline starting" className="flex flex-col gap-2 animate-pulse">
            {[...Array(5)].map((_, i) => <div key={i} aria-hidden="true" className="h-3 bg-zinc-900 rounded" style={{ width: `${65 + (i % 3) * 15}%` }} />)}
          </div>
        )}
        {(isSuccess || (isLoading && content)) && (
          <><StreamRenderer content={content} /><StreamingCursor /></>
        )}
        {sessionState.status === 'error' && (
          <div role="alert" aria-live="assertive" className="text-red-400 text-xs font-mono">
            <p className="font-semibold mb-1">Stream Error</p>
            <p>{sessionState.message}</p>
            <p className="text-zinc-600 mt-1 text-xs">ID: {sessionState.metadata.correlationId}</p>
          </div>
        )}
        <div ref={bottomRef} aria-hidden="true" />
      </div>

      {showScrollBtn && (
        <button type="button" onClick={scrollToBottom} aria-label="Scroll to latest output"
          className="absolute bottom-4 right-4 z-10 flex items-center justify-center w-8 h-8 rounded-full bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-300 text-sm transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400">
          <span aria-hidden="true">↓</span>
        </button>
      )}
    </section>
  )
}
