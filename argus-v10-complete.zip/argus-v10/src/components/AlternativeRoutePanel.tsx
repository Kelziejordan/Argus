// filepath: src/components/AlternativeRoutePanel.tsx

'use client'

import { memo } from 'react'
import { useArgusSession } from '@/providers/ArgusSessionProvider'
import { StreamRenderer }  from './StreamRenderer'

export const AlternativeRoutePanel = memo(function AlternativeRoutePanel() {
  const { sessionState } = useArgusSession()
  const content = sessionState.status === 'success' ? sessionState.data.panelContent.alternative : ''
  const hasContent = content.trim().length > 0

  return (
    <section aria-label="Alternative Architecture — Process 8" className="flex flex-col h-full bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
      <header className="px-3 py-2 border-b border-zinc-800 bg-zinc-900/50 flex-shrink-0">
        <h2 className="text-zinc-300 text-xs font-mono font-semibold tracking-widest uppercase">Alternative Route</h2>
      </header>
      <div className="flex-1 overflow-y-auto overscroll-contain p-3" tabIndex={hasContent ? 0 : undefined}>
        {!hasContent
          ? <p aria-live="polite" className="text-zinc-700 text-xs font-mono leading-relaxed">Alternative architecture analysis will appear here during Process 8.</p>
          : <StreamRenderer content={content} />
        }
      </div>
    </section>
  )
})
