// filepath: src/components/OpportunityPanel.tsx

'use client'

import { memo } from 'react'
import { useArgusSession } from '@/providers/ArgusSessionProvider'
import type { Opportunity, OpportunityEffort, OpportunityConfidence } from '@/types'

const EFFORT_STYLE: Record<OpportunityEffort, string> = {
  low:    'bg-green-950  text-green-400  border-green-900',
  medium: 'bg-amber-950  text-amber-400  border-amber-900',
  high:   'bg-red-950    text-red-400    border-red-900',
}

const CONFIDENCE_STYLE: Record<OpportunityConfidence, string> = {
  speculative: 'bg-zinc-900  text-zinc-500  border-zinc-800',
  likely:      'bg-blue-950  text-blue-400  border-blue-900',
  strong:      'bg-cyan-950  text-cyan-400  border-cyan-900',
}

function OpportunityCard({ opportunity, index }: { opportunity: Opportunity; index: number }) {
  return (
    <article aria-label={`Opportunity ${index + 1}: ${opportunity.title}`}
      className="flex flex-col gap-2 p-3 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-cyan-900/50 transition-colors duration-200">
      <h3 className="text-cyan-400 text-xs font-mono font-semibold leading-snug">{opportunity.title}</h3>
      <div className="flex flex-wrap items-center gap-1.5">
        <span aria-label={`Domain: ${opportunity.domain}`} className="px-2 py-0.5 rounded text-xs font-mono bg-zinc-800 text-zinc-400 border border-zinc-700">{opportunity.domain}</span>
        <span aria-label={`Effort: ${opportunity.effort}`} className={`px-2 py-0.5 rounded text-xs font-mono border ${EFFORT_STYLE[opportunity.effort]}`}>{opportunity.effort}</span>
        <span aria-label={`Confidence: ${opportunity.confidence}`} className={`px-2 py-0.5 rounded text-xs font-mono border ${CONFIDENCE_STYLE[opportunity.confidence]}`}>{opportunity.confidence}</span>
        <span aria-label={`Process ${opportunity.detected_at_process}`} className="px-2 py-0.5 rounded text-xs font-mono bg-zinc-900 text-zinc-600 border border-zinc-800">P{opportunity.detected_at_process}</span>
      </div>
      <p className="text-zinc-400 text-xs font-mono leading-relaxed"><span className="text-zinc-600">Revenue: </span>{opportunity.revenue_model}</p>
      <p className="text-zinc-500 text-xs font-mono leading-relaxed line-clamp-3">{opportunity.description}</p>
    </article>
  )
}

export const OpportunityPanel = memo(function OpportunityPanel() {
  const { liveOpportunities, detectedCount } = useArgusSession()

  return (
    <section aria-label={`Live Opportunities — ${detectedCount} detected`} className="flex flex-col h-full bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
      <header className="flex items-center justify-between px-3 py-2 border-b border-zinc-800 bg-zinc-900/50 flex-shrink-0">
        <h2 className="text-zinc-300 text-xs font-mono font-semibold tracking-widest uppercase">Live Opportunities</h2>
        {detectedCount > 0 && (
          <span aria-label={`${detectedCount} detected`} className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-950 border border-cyan-900 text-cyan-400 text-xs font-mono font-bold">{detectedCount}</span>
        )}
      </header>
      <div className="flex-1 overflow-y-auto overscroll-contain p-3 flex flex-col gap-2" aria-live="polite" aria-atomic="false" aria-relevant="additions">
        {liveOpportunities.length === 0
          ? <p className="text-zinc-700 text-xs font-mono leading-relaxed text-center py-6">Opportunities will appear here as ARGUS detects them during the pipeline.</p>
          : liveOpportunities.map((opp, i) => <OpportunityCard key={`${opp.title}-${i}`} opportunity={opp} index={i} />)
        }
      </div>
    </section>
  )
})
