// filepath: app/layout.tsx

import type { Metadata } from 'next'
import { RootErrorBoundary }     from '@/components/boundaries/RootErrorBoundary'
import { ArgusSessionProvider }  from '@/providers/ArgusSessionProvider'
import './globals.css'

export const metadata: Metadata = {
  title:       'ARGUS V10 — AI Software Architect',
  description: 'Principal-level AI-driven system architecture and code generation.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <meta name="color-scheme" content="dark" />
        <meta name="theme-color" content="#09090b" />
      </head>
      <body className="bg-zinc-950 text-zinc-100 font-sans antialiased overflow-hidden">
        <RootErrorBoundary>
          <ArgusSessionProvider>
            {children}
          </ArgusSessionProvider>
        </RootErrorBoundary>
      </body>
    </html>
  )
}
