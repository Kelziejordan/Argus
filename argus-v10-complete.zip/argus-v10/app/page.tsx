// filepath: app/page.tsx

'use client'

import { PanelErrorBoundary }      from '@/components/boundaries/PanelErrorBoundary'
import { StreamOutputPanel }        from '@/components/StreamOutputPanel'
import { PipelineProgressPanel }    from '@/components/PipelineProgressPanel'
import { NextMovePanel }            from '@/components/NextMovePanel'
import { AlternativeRoutePanel }    from '@/components/AlternativeRoutePanel'
import { ArgusInputPanel }          from '@/components/ArgusInputPanel'
import { OpportunityPanel }         from '@/components/OpportunityPanel'
import { OpportunityHistoryPanel }  from '@/components/OpportunityHistoryPanel'

export default function ArgusWorkspacePage() {
  return (
    <main className="h-screen overflow-hidden bg-zinc-950" aria-label="ARGUS V10 Workspace">
      <div className="h-full flex flex-col gap-3 p-3 overflow-hidden">

        {/* Top section — Stream Output (left) + Right panel stack */}
        <div className="flex-1 grid grid-cols-[1.5fr_1fr] gap-3 min-h-0">
          <div className="min-h-0">
            <PanelErrorBoundary panelName="Stream Output">
              <StreamOutputPanel />
            </PanelErrorBoundary>
          </div>
          <div className="grid grid-rows-[1fr_1fr_1fr] gap-3 min-h-0">
            <div className="min-h-0">
              <PanelErrorBoundary panelName="Pipeline Progress">
                <PipelineProgressPanel />
              </PanelErrorBoundary>
            </div>
            <div className="min-h-0">
              <PanelErrorBoundary panelName="Next Move">
                <NextMovePanel />
              </PanelErrorBoundary>
            </div>
            <div className="min-h-0">
              <PanelErrorBoundary panelName="Alternative Route">
                <AlternativeRoutePanel />
              </PanelErrorBoundary>
            </div>
          </div>
        </div>

        {/* Input panel — full width */}
        <div className="h-auto">
          <PanelErrorBoundary panelName="ARGUS Input">
            <ArgusInputPanel />
          </PanelErrorBoundary>
        </div>

        {/* Bottom section — Live Opportunities + History */}
        <div className="flex-1 grid grid-cols-[1fr_1.5fr] gap-3 min-h-0">
          <div className="min-h-0">
            <PanelErrorBoundary panelName="Live Opportunities">
              <OpportunityPanel />
            </PanelErrorBoundary>
          </div>
          <div className="min-h-0">
            <PanelErrorBoundary panelName="Opportunity History">
              <OpportunityHistoryPanel />
            </PanelErrorBoundary>
          </div>
        </div>

      </div>
    </main>
  )
}
